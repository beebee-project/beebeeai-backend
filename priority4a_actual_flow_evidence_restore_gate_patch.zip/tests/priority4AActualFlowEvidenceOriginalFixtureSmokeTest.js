"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");
const {
  detectActualFlowEvidence,
} = require("../automation/semanticOutputPlanner");

function parseCsv(file) {
  const text = fs.readFileSync(file, "utf8").replace(/^\uFEFF/, "");
  const lines = text.trim().split(/\r?\n/);
  const headers = lines[0].split(",");
  const rows = lines.slice(1).map((line) => {
    const values = line.split(",");
    return Object.fromEntries(headers.map((header, index) => [header, values[index]]));
  });
  return {
    tableId: path.basename(file),
    tableName: path.basename(file),
    columns: headers.map((header) => ({ header, key: header })),
    rows,
  };
}

const root = path.join(__dirname, "fixtures", "metric-semantic-role");
const expectations = [
  ["inventory_stock_status.csv", true, "explicit_inbound_outbound_columns"],
  ["warehouse_movement_report.csv", true, "direction_column_with_quantity"],
  ["supply_usage_report.csv", false, "no_actual_flow_evidence"],
  ["equipment_rental_status.csv", false, "no_actual_flow_evidence"],
  ["asset_equipment_management.csv", false, "no_actual_flow_evidence"],
  ["travel_expense_settlement_analysis.csv", false, "no_actual_flow_evidence"],
  ["energy_usage_report.csv", false, "no_actual_flow_evidence"],
];

for (const [fileName, expectedPass, expectedMode] of expectations) {
  const table = parseCsv(path.join(root, fileName));
  const snapshot = JSON.stringify(table);
  const result = detectActualFlowEvidence([table]);
  assert.strictEqual(JSON.stringify(table), snapshot, `${fileName}: source mutated`);
  assert.strictEqual(result.pass, expectedPass, `${fileName}: pass`);
  assert.strictEqual(result.mode, expectedMode, `${fileName}: mode`);
}

console.log("PASS priority4A actual flow evidence original fixture smoke: 7");
