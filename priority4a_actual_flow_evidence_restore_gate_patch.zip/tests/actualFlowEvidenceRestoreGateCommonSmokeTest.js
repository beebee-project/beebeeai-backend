"use strict";

const assert = require("assert");
const {
  ACTUAL_FLOW_EVIDENCE_GATE_VERSION,
  canonicalActualFlowDirection,
  detectActualFlowEvidence,
} = require("../automation/semanticOutputPlanner");

function table(columns, rows, tableName = "테스트 표") {
  return {
    tableId: tableName,
    tableName,
    columns: columns.map((header) => ({ header, key: header })),
    rows,
  };
}

const inventory = table(
  ["기준일", "품목명", "입고수량", "출고수량", "현재재고"],
  [
    { 기준일: "2026-01-31", 품목명: "A", 입고수량: 10, 출고수량: 3, 현재재고: 7 },
    { 기준일: "2026-02-28", 품목명: "A", 입고수량: 4, 출고수량: 2, 현재재고: 9 },
  ],
  "재고 현황",
);
const warehouse = table(
  ["이동일", "이동구분", "이동수량", "출발창고", "도착창고"],
  [
    { 이동일: "2026-01-01", 이동구분: "입고", 이동수량: 20, 출발창고: "외부", 도착창고: "A" },
    { 이동일: "2026-01-02", 이동구분: "출고", 이동수량: 5, 출발창고: "A", 도착창고: "외부" },
    { 이동일: "2026-01-03", 이동구분: "이동", 이동수량: 7, 출발창고: "A", 도착창고: "B" },
  ],
  "창고 이동",
);
const supply = table(
  ["사용일", "소모품명", "사용수량", "잔여수량", "사용금액"],
  [
    { 사용일: "2026-01-01", 소모품명: "A", 사용수량: 10, 잔여수량: 90, 사용금액: 1000 },
    { 사용일: "2026-02-01", 소모품명: "A", 사용수량: 20, 잔여수량: 70, 사용금액: 2000 },
  ],
  "소모품 사용",
);
const rental = table(
  ["대여일", "장비명", "대여수량", "대여상태"],
  [
    { 대여일: "2026-01-01", 장비명: "A", 대여수량: 2, 대여상태: "대여중" },
    { 대여일: "2026-01-02", 장비명: "B", 대여수량: 1, 대여상태: "반납완료" },
  ],
  "장비 대여",
);
const falseDirection = table(
  ["처리구분", "처리수량"],
  [
    { 처리구분: "사용", 처리수량: 3 },
    { 처리구분: "대여", 처리수량: 2 },
  ],
  "일반 처리",
);

for (const source of [inventory, warehouse, supply, rental, falseDirection]) {
  const snapshot = JSON.stringify(source);
  detectActualFlowEvidence([source]);
  assert.strictEqual(JSON.stringify(source), snapshot, "must not mutate source table");
}

const inventoryEvidence = detectActualFlowEvidence([inventory]);
assert.strictEqual(inventoryEvidence.version, ACTUAL_FLOW_EVIDENCE_GATE_VERSION);
assert.strictEqual(inventoryEvidence.pass, true);
assert.strictEqual(inventoryEvidence.mode, "explicit_inbound_outbound_columns");
assert.strictEqual(inventoryEvidence.tableEvidence[0].inboundHeader, "입고수량");
assert.strictEqual(inventoryEvidence.tableEvidence[0].outboundHeader, "출고수량");

const warehouseEvidence = detectActualFlowEvidence([warehouse]);
assert.strictEqual(warehouseEvidence.pass, true);
assert.strictEqual(warehouseEvidence.mode, "direction_column_with_quantity");
assert.strictEqual(warehouseEvidence.tableEvidence[0].directionHeader, "이동구분");
assert.strictEqual(warehouseEvidence.tableEvidence[0].quantityHeader, "이동수량");
assert.deepStrictEqual(
  warehouseEvidence.tableEvidence[0].directionClasses,
  ["inbound", "outbound", "transfer"],
);

for (const source of [supply, rental, falseDirection]) {
  const evidence = detectActualFlowEvidence([source]);
  assert.strictEqual(evidence.pass, false);
  assert.strictEqual(evidence.mode, "no_actual_flow_evidence");
}

assert.strictEqual(canonicalActualFlowDirection("입고"), "inbound");
assert.strictEqual(canonicalActualFlowDirection("출고"), "outbound");
assert.strictEqual(canonicalActualFlowDirection("이동"), "transfer");
assert.strictEqual(canonicalActualFlowDirection("사용"), "");
assert.strictEqual(canonicalActualFlowDirection("대여"), "");

console.log("PASS actual flow evidence restore gate common smoke");
