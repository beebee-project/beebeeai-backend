"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");

const source = fs.readFileSync(
  path.join(__dirname, "..", "automation", "semanticOutputPlanner.js"),
  "utf8",
);

const forbidden = [
  "template_inventory_stock_status",
  "template_supply_usage_report",
  "template_warehouse_movement_report",
  "template_equipment_rental_status",
  "inventory_stock_status.csv",
  "supply_usage_report.csv",
  "warehouse_movement_report.csv",
  "equipment_rental_status.csv",
  "caseId ===",
  "fileName ===",
  "return 815",
  "return 1075",
  "return 211",
  "return 205",
];
for (const token of forbidden) {
  assert.strictEqual(
    source.includes(token),
    false,
    `Production source must not hardcode ${token}`,
  );
}

for (const token of [
  "semantic_output_planner_common_v2_8_actual_flow_evidence_restore_gate",
  "actual_flow_evidence_restore_gate_v1",
  "explicit_inbound_outbound_columns",
  "direction_column_with_quantity",
  "MIXED_FLOW_SECTION_BLOCKED_NO_ACTUAL_FLOW_EVIDENCE",
  "actualFlowEvidencePass",
  "blockedMixedFlowSectionCount",
]) {
  assert(source.includes(token), `missing common implementation token: ${token}`);
}

console.log("PASS actual flow evidence restore gate source integrity");
