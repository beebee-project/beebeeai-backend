"use strict";

const assert = require("assert");
const fs = require("fs");
const path = require("path");

const source = fs.readFileSync(
  path.join(__dirname, "..", "automation", "semanticOutputPlanner.js"),
  "utf8",
);

const forbidden = [
  "template_inventory_stock_status",
  "inventory_stock_status.csv",
  "caseId ===",
  "fileName ===",
  "return 211",
  "return 1203",
  "return 3229000",
];
for (const token of forbidden) {
  assert.strictEqual(
    source.includes(token),
    false,
    `Production source must not hardcode ${token}`,
  );
}

for (const token of [
  "semantic_output_planner_common_v2_8_actual_flow_evidence_restore_gate",
  "general_stock_snapshot_alias_v2_pre_finalization_row_shape",
  "general_stock_snapshot_alias_preclassification",
  "overriddenRole: classified.role",
]) {
  assert(source.includes(token), `missing common implementation token: ${token}`);
}

console.log("PASS actual mixed section row shape source integrity");
