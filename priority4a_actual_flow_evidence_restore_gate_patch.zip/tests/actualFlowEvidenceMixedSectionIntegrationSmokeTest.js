"use strict";

const assert = require("assert");
const {
  detectActualFlowEvidence,
  resolveSemanticContractConflicts,
} = require("../automation/semanticOutputPlanner");

function table(columns, rows, tableName) {
  return {
    tableId: tableName,
    tableName,
    columns: columns.map((header) => ({ header, key: header })),
    rows,
  };
}

function latestSummary({ sectionId, metric, value, count = 2, metricIds = [] }) {
  return {
    sectionId,
    title: `${metric} 최신 스냅샷`,
    sectionType: "semantic_snapshot_summary",
    metricIds,
    result: {
      operation: "semanticLatestSnapshot",
      metric: { header: metric },
      metricIds,
      rows: [
        { 지표: "최신 스냅샷 값", 값: value },
        { 지표: "선택 행 수", 값: count },
      ],
    },
  };
}

function mixedOverview({ stockLabel = "재고 수량 합계", stockValue = 100, metricIds = [] } = {}) {
  return {
    sectionId: "inventory_flow_overview",
    title: "재고·입출고 흐름 요약",
    sectionType: "inventory_flow_overview",
    metricIds,
    result: {
      resultType: "inventory_flow_overview",
      operation: "summary",
      metricIds,
      rows: [
        { 지표: "전체 행 수", 값: 2 },
        { 지표: "입고 수량", 값: 10 },
        { 지표: "출고 수량", 값: 3 },
        { 지표: "순증감 수량", 값: 7 },
        { 지표: stockLabel, 값: stockValue },
      ],
    },
  };
}

const actualInventoryTable = table(
  ["기준일", "입고수량", "출고수량", "현재재고"],
  [
    { 기준일: "2026-01-31", 입고수량: 10, 출고수량: 3, 현재재고: 7 },
    { 기준일: "2026-02-28", 입고수량: 4, 출고수량: 2, 현재재고: 9 },
  ],
  "재고",
);
const supplyTable = table(
  ["사용일", "소모품명", "사용수량", "잔여수량"],
  [
    { 사용일: "2026-01-01", 소모품명: "A", 사용수량: 10, 잔여수량: 90 },
    { 사용일: "2026-02-01", 소모품명: "A", 사용수량: 20, 잔여수량: 70 },
  ],
  "소모품 사용",
);
const rentalTable = table(
  ["대여일", "장비명", "대여수량", "대여상태"],
  [
    { 대여일: "2026-01-01", 장비명: "A", 대여수량: 2, 대여상태: "대여중" },
    { 대여일: "2026-01-02", 장비명: "B", 대여수량: 1, 대여상태: "반납완료" },
  ],
  "장비 대여",
);

const current = latestSummary({
  sectionId: "semantic.current.latest.summary",
  metric: "현재재고",
  value: 16,
  metricIds: ["semantic.current"],
});
const remaining = latestSummary({
  sectionId: "semantic.remaining.latest.summary",
  metric: "잔여수량",
  value: 70,
  metricIds: ["semantic.remaining"],
});

const inventoryOverview = mixedOverview({ metricIds: ["legacy.inventory.flow"] });
const inventoryInput = [inventoryOverview, current];
const inventorySnapshot = JSON.stringify(inventoryInput);
const inventoryResult = resolveSemanticContractConflicts({
  sections: inventoryInput,
  plannedSections: [current],
  baseSectionCount: 1,
  actualFlowEvidence: detectActualFlowEvidence([actualInventoryTable]),
});
assert.strictEqual(JSON.stringify(inventoryInput), inventorySnapshot);
assert.strictEqual(inventoryResult.blockedMixedFlowSectionCount, 0);
const retained = inventoryResult.sections.find(
  (section) => section.sectionId === inventoryOverview.sectionId,
);
assert(retained, "actual inventory flow overview must be retained");
assert(retained.result.rows.some((row) => row.지표 === "현재재고 최신 스냅샷" && row.값 === 16));

const supplyOverview = mixedOverview({
  stockLabel: "잔여수량 합계",
  stockValue: 160,
  metricIds: ["legacy.supply.flow"],
});
const supplyInput = [supplyOverview, remaining];
const supplySnapshot = JSON.stringify(supplyInput);
const supplyResult = resolveSemanticContractConflicts({
  sections: supplyInput,
  plannedSections: [remaining],
  baseSectionCount: 1,
  actualFlowEvidence: detectActualFlowEvidence([supplyTable]),
});
assert.strictEqual(JSON.stringify(supplyInput), supplySnapshot);
assert.strictEqual(supplyResult.blockedMixedFlowSectionCount, 1);
assert.strictEqual(
  supplyResult.sections.some((section) => section.sectionId === supplyOverview.sectionId),
  false,
  "usage-only table must not retain inventory flow overview",
);
assert.strictEqual(
  supplyResult.blockedMixedFlowSections[0].reason,
  "MIXED_FLOW_SECTION_BLOCKED_NO_ACTUAL_FLOW_EVIDENCE",
);
assert(
  supplyResult.sections
    .find((section) => section.sectionId === remaining.sectionId)
    .metricIds.includes("legacy.supply.flow"),
  "legacy metric ids must be transferred before blocking",
);

const rentalOverview = mixedOverview({
  stockLabel: "대여수량 합계",
  stockValue: 3,
});
const rentalResult = resolveSemanticContractConflicts({
  sections: [rentalOverview, current],
  plannedSections: [current],
  baseSectionCount: 1,
  actualFlowEvidence: detectActualFlowEvidence([rentalTable]),
});
assert.strictEqual(rentalResult.blockedMixedFlowSectionCount, 1);
assert.strictEqual(
  rentalResult.sections.some((section) => section.sectionId === rentalOverview.sectionId),
  false,
  "rental quantity alone must not retain inventory flow overview",
);

console.log("PASS actual flow evidence mixed section integration smoke");
